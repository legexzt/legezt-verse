const chatBox = document.getElementById("chatBox");
const sendBtn = document.getElementById("sendBtn");
const userInput = document.getElementById("userInput");
const typingIndicator = document.getElementById("typingIndicator");

const chatHistory = [];

function appendMessage(msg, type) {
  const div = document.createElement("div");
  div.className = `bubble ${type}-msg`;
  div.innerText = msg;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendRoast() {
  const msg = userInput.value.trim();
  if (!msg) return;

  appendMessage(msg, "user");
  chatHistory.push({ role: "user", content: msg });
  userInput.value = "";
  typingIndicator.style.display = "block";

  try {
    const res = await fetch("/roast", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ history: [{ role: "user", content: msg }] })
    });

    const data = await res.json();
    const roast = data.roast || "🔥 Kuch to ghalat bola be!";
    setTimeout(() => {
      appendMessage(roast, "bot");
      chatHistory.push({ role: "assistant", content: roast });
      typingIndicator.style.display = "none";
    }, 800);

  } catch (err) {
    appendMessage("❌ Server down hai kya? 😅", "bot");
    typingIndicator.style.display = "none";
  }
}

sendBtn.addEventListener("click", sendRoast);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendRoast();
});

function startNewChat() {
  chatBox.innerHTML = "";
  userInput.value = "";
  userInput.focus();
}
