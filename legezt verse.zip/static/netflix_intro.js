// netflix_intro.js

window.addEventListener("load", () => {
  const intro = document.getElementById("netflixIntro");
  const sound = document.getElementById("introSound");
  const main = document.getElementById("mainContent");

  if (!sessionStorage.getItem("introPlayed")) {
    try {
      sound.play();
    } catch (e) {
      console.warn("Audio autoplay blocked");
    }
    setTimeout(() => {
      intro.classList.add("fade-out");
      setTimeout(() => {
        intro.style.display = "none";
        main.style.display = "block";
      }, 1000);
    }, 3000);
    sessionStorage.setItem("introPlayed", "true");
  } else {
    intro.style.display = "none";
    main.style.display = "block";
  }
});
