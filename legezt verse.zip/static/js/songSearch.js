document.addEventListener("DOMContentLoaded", () => {
  const downloadBtn = document.getElementById("downloadBtn");
  const videoInput = document.getElementById("videoId");
  const status = document.getElementById("status");

  downloadBtn.addEventListener("click", async () => {
    const videoId = videoInput.value.trim();
    if (!videoId) {
      status.innerText = "❌ Please enter a video ID.";
      return;
    }

    status.innerText = "⏳ Downloading...";

    const response = await fetch("/download-mp3", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videoId })
    });

    if (!response.ok) {
      status.innerText = "❌ Error downloading.";
      return;
    }

    const blob = await response.blob();
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${videoId}.mp3`;
    link.click();

    status.innerText = "✅ Download ready!";
  });
});
